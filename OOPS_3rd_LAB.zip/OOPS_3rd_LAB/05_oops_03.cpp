#include <iostream>
using namespace std;

class MyClass {
private:
    int num;
public:
    MyClass(int n) {
        num = n;
        cout << "Constructor called with num: " << num << endl;
    }
    
    ~MyClass() {
        cout << "Destructor called for num: " << num << endl;
    }
    
    void display() {
        cout << "The number is: " << num << endl;
    }
};

int main() {
    MyClass obj(50);
    obj.display();
    
    return 0;
}
