#include <iostream>
using namespace std;

class MyClass {
private:
    int num;
public:
    MyClass(); 
    MyClass(int n);
    void display();
};


MyClass::MyClass() {
    num = 0;
}


MyClass::MyClass(int n) {
    num = n;
}

void MyClass::display() {
    cout << "The number is: " << num << endl;
}

int main() {
    MyClass obj1;       
    MyClass obj2(100);    
    
    obj1.display();
    obj2.display();
    
    return 0;
}
