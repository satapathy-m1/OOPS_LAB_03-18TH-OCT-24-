#include <iostream>
using namespace std;

class MyClass {
private:
    static int count; 
public:
    MyClass() {
        count++;
	cout << "Constructor " << endl;
    }
    ~MyClass(){
	count--;
	cout << "Destructor " << endl;
    }
    static void displayCount() { 
        cout << "Count: " << count << endl;
    }
};

int MyClass::count = 0;

int main() {
    MyClass obj1;
    cout << "Before local block" << endl;
    MyClass :: displayCount();
{
    MyClass obj2;
    cout << "Inside local block " << endl;
    MyClass :: displayCount();
}   
    cout << "After local block" << endl;
    MyClass::displayCount();
    
    return 0;
}
