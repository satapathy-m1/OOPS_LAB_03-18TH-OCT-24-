#include <iostream>
using namespace std;

class MyClass {
private:
    int num;
public:
    MyClass() {
        num = 10;
    }
    
    inline void setNum(int n) { num = n; } 
    void display() {
        cout << "The number is: " << num << endl;
    }
};

inline void MyClass::display() { 
    cout << "The number is: " << num << endl;
}

int main() {
    MyClass obj;
    obj.setNum(42); 
    obj.display();   
    
    return 0;
}
