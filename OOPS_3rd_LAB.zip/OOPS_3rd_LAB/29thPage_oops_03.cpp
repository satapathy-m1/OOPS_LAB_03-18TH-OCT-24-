#include <iostream>
using namespace std;

class Employee {
private:
    int EmployeeNumber;         
    string EmployeeName;        
    int BasicSalary;            
    int AllAllowances;          
    int IncomeTax;              
    int NetSalary;              
    int GrossSalary;            

public:
    
    void getData() {
        cout << "Enter Employee Number: ";
        cin >> EmployeeNumber;
        cout << "Enter Employee Name: ";
        cin >> EmployeeName;
        cout << "Enter Basic Salary: ";
        cin >> BasicSalary;
    }


    void calculateNetSalary() {
        AllAllowances = (123.00/100.00) * BasicSalary; 
        GrossSalary = BasicSalary + AllAllowances; 
        IncomeTax =(30.00/100.00) * GrossSalary;  
        NetSalary = GrossSalary - IncomeTax;  
    }


    void displayInformation() {
        cout << "Employee Number: " << EmployeeNumber << endl;
        cout << "Employee Name: " << EmployeeName << endl;
        cout << "Basic Salary: " << BasicSalary << endl;
        cout << "All Allowances" << AllAllowances << endl;
        cout << "Gross Salary (Basic Salary + All Allowances): " << GrossSalary << endl;
        cout << "Income Tax : " << IncomeTax << endl;
        cout << "Net Salary (Gross Salary - Income Tax): " << NetSalary << endl;
    }
};

int main() {
    Employee emp;
    
    emp.getData();
    
    emp.calculateNetSalary();
    
    emp.displayInformation();
    
    return 0;
}

