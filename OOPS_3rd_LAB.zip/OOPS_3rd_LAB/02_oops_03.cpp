#include <iostream>
using namespace std;

class MyClass {
private:
    int num;
public:
    MyClass(); 
    void setNum(int n); 
    void display(); 
};


MyClass::MyClass() {
    num = 0;
}

void MyClass::setNum(int n) {
    num = n;
}


void MyClass::display() {
    cout << "The number is: " << num << endl;
}

int main() {
    MyClass obj;
    obj.setNum(42);
    obj.display();
    
    return 0;
}
