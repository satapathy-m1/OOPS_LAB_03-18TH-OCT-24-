#include <iostream>
using namespace std;

class MyClass {
private:
    int num;
public:
    MyClass() {
        num = 10;
    }
    
    void display() {
        cout << "The number is: " << num << endl;
    }
};


MyClass globalObj;

int main() {
    
    MyClass localObj;
    
    localObj.display();  
    globalObj.display(); 
    
    return 0;
}
