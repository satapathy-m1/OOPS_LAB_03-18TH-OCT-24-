#include <iostream>
using namespace std;

class MyClass {
public:
	//FROM THESE FUNCTIONS ONLY THE APPROPRIATE FUNCTION GETS CALLED THROUGH EXAMINING ITS PARA,ETERS GIVEN.
    void display(int num) {
        cout << "Displaying integer: " << num << endl;
    }
    
    void display(string str) {
        cout << "Displaying string: " << str << endl;
    }
    
    void display(double num) {
        cout << "Displaying double: " << num << endl;
    }
};

int main() {
    MyClass obj;
    obj.display(42);
    obj.display("Hello, World!");
    obj.display(3.14);
    
    return 0;
}
