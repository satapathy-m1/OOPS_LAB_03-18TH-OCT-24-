#include <iostream>
using namespace std;

class MyClass {
private:
    int privateVar;
protected:
    int protectedVar; 
public:
    int publicVar; 
    
    
    MyClass() {
        privateVar = 10;
        protectedVar = 20;
        publicVar = 30;
    }
    
    
    void show() {
        cout << "Private Var: " << privateVar << endl;
        cout << "Protected Var: " << protectedVar << endl;
        cout << "Public Var: " << publicVar << endl;
    }
    
    // Function to set privateVar
    void setPrivateVar(int value) {
        privateVar = value;
    }
    
    // Function to get privateVar
    int getPrivateVar() {
        return privateVar;
    }
};

int main() {
    MyClass obj;
    
    obj.show();
    
    obj.setPrivateVar(100);
    cout << "Updated Private Var: " << obj.getPrivateVar() << endl;
    
    return 0;
}
